package com.cgTrainee.TdsDetails_46002419;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TdsDetails46002419Application {

	public static void main(String[] args) {
		SpringApplication.run(TdsDetails46002419Application.class, args);
	}

}
