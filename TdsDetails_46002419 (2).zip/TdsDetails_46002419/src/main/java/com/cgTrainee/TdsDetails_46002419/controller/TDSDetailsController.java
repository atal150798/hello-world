package com.cgTrainee.TdsDetails_46002419.controller;



import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cgTrainee.TdsDetails_46002419.entity.TDSDetails;
import com.cgTrainee.TdsDetails_46002419.exception.TdsNotFoundException;
import com.cgTrainee.TdsDetails_46002419.service.TDSService;


@RestController
public class TDSDetailsController {

	@Autowired
	private TDSService service;
	
	@GetMapping(value = "/tds/{id}")
	public TDSDetails getTdsById(@PathVariable("id") ObjectId id) throws TdsNotFoundException {
		TDSDetails result = service.getTdsById(id);
		if (result != null) {
			return result;
		} else {
			throw new TdsNotFoundException("TDS Details not found");
		}
	}
	// Global Exception Handler... HttpStatus and Message...
		@ResponseStatus(code = HttpStatus.BAD_REQUEST, reason = "Student not present")
		@ExceptionHandler(Exception.class)
		public void handleStudentNotFoundException() {
			System.out.println("Invalid input or Data is not available");

		}
}
