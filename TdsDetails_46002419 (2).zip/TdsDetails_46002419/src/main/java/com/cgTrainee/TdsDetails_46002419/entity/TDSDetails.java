package com.cgTrainee.TdsDetails_46002419.entity;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection ="tdsdetail")
public abstract class TDSDetails {
	@Id
	private ObjectId _id;
	
	private Integer unique_id;
	private String deductor_name;
	private String deductor_pan;
	private Integer tds_deposited;
	
	public ObjectId get_id() {
		return _id;
	}
	public void set_id(ObjectId _id) {
		this._id = _id;
	}
	public Integer getUnique_id() {
		return unique_id;
	}
	public void setUnique_id(Integer unique_id) {
		this.unique_id = unique_id;
	}
	public String getDeductor_name() {
		return deductor_name;
	}
	public void setDeductor_name(String deductor_name) {
		this.deductor_name = deductor_name;
	}
	public String getDeductor_pan() {
		return deductor_pan;
	}
	public void setDeductor_pan(String deductor_pan) {
		this.deductor_pan = deductor_pan;
	}
	public Integer getTds_deposited() {
		return tds_deposited;
	}
	public void setTds_deposited(Integer tds_deposited) {
		this.tds_deposited = tds_deposited;
	}
	@Override
	public String toString() {
		return "TDSDetails [_id=" + _id + ", unique_id=" + unique_id + ", deductor_name=" + deductor_name
				+ ", deductor_pan=" + deductor_pan + ", tds_deposited=" + tds_deposited + "]";
	}
	public TDSDetails() {
		
	}
	
	
	
	

}
