package com.cgTrainee.TdsDetails_46002419.service;

import org.bson.types.ObjectId;

import com.cgTrainee.TdsDetails_46002419.entity.TDSDetails;


public interface TDSService {
	
	public TDSDetails getTdsById(ObjectId id);
}
