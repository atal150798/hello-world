package com.cgTrainee.TdsDetails_46002419.service;



import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cgTrainee.TdsDetails_46002419.dao.TDSDao;
import com.cgTrainee.TdsDetails_46002419.entity.TDSDetails;

@Service
public class TDSServiceImpl implements TDSService {
	
	@Autowired
	private TDSDao dao;
	
	// The StudentInfoRepository will use the Mongodb-Repository to perform the database operations.
	
	  @Autowired 
	  public TDSServiceImpl(TDSDao dao) { 
		  this.dao = dao; 
		  }
	 
	
	@Override
	public TDSDetails getTdsById(ObjectId id) {
		return dao.findBy_Id(id);
	}

}
