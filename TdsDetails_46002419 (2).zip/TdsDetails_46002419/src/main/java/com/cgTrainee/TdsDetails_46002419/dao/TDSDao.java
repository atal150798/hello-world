package com.cgTrainee.TdsDetails_46002419.dao;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.cgTrainee.TdsDetails_46002419.entity.TDSDetails;



public interface TDSDao extends MongoRepository<TDSDetails, String>{

	TDSDetails findBy_Id(ObjectId _id);
	
}
