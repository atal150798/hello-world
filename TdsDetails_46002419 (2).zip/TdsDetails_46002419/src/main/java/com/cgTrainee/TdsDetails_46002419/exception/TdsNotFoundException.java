package com.cgTrainee.TdsDetails_46002419.exception;

public class TdsNotFoundException extends Exception {
	// Exception Class StudentNotFoundException.....
		private static final long serialVersionUID = 1L;
		public TdsNotFoundException(String msg) {
			super(msg);
		}
}
