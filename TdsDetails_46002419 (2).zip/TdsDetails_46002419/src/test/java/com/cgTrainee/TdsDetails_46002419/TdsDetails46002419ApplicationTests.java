package com.cgTrainee.TdsDetails_46002419;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TdsDetails46002419ApplicationTests {

	@Test
	void contextLoads() {
	}

}
